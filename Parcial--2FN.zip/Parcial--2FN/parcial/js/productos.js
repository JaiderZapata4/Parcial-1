const productos = [
  {
    nombre: "Aventura y Naturaleza",
    descripcion: "Diversión al aire libre, llenos de travesías y lugares emblemáticos.",
  },
  {
    nombre: "Deporte y Entretenimiento",
    descripcion: "Diversion sin fin, con recorridos y momentos unicos.",
  },
  {
    nombre: "Arte y Comida",
    descripcion: "Recorridos unicos y coloridos llenos de magia en cada momento.",
  },
  {
    nombre: "Cultura e Historia",
    descripcion: "Conocimiento y tradiciones, guardando experiencias y sonrisas",
  },
  {
    nombre: "Accion y Aventura",
    descripcion: "Recorridos emblemáticos, llenos de sonrisas y adrenalina.",
  },
  {
    nombre: "Tranquilidad y Descanso",
    descripcion: "Serenidad y descanso acompañado de los mejores paisajes.",
  },
];

function mostrarProductos() {
  const productosContainer = document.getElementById("productos-container");

  productos.forEach((producto, index) => {
    const productoDiv = document.createElement("div");
    productoDiv.classList.add("producto");

    productoDiv.innerHTML = `
      <h3>${producto.nombre}</h3>
      <p>${producto.descripcion}</p>
    `;

    productosContainer.appendChild(productoDiv);
  });
}

mostrarProductos();
