document.addEventListener("DOMContentLoaded", function () {
    const colaboradoresData = [
      { nombre: "Administrador", imagenSrc: "imagenes/administraddor.png" },
      { nombre: "Vendedor", imagenSrc: "imagenes/vendedor.png" },
      { nombre: "Guia", imagenSrc: "imagenes/guia-turistico.png" },


    ];
  
    const colaboradoresSection = document.getElementById("colaboradores");
  
    colaboradoresData.forEach((colaborador) => {
      const colaboradorElement = createColaboradorElement(colaborador);
      colaboradoresSection.appendChild(colaboradorElement);
    });
  });
  
  function createColaboradorElement(colaborador) {
    const boxImagen = document.createElement("div");
    boxImagen.classList.add("box-imagen");
  
    const img = document.createElement("img");
    img.src = colaborador.imagenSrc;
    img.alt = colaborador.nombre;
  
    const p = document.createElement("p");
    p.textContent = colaborador.nombre;
  
    boxImagen.appendChild(img);
    boxImagen.appendChild(p);
  
    return boxImagen;
  }
  